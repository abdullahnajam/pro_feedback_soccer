package com.feedback.pro_feedback_soccer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
